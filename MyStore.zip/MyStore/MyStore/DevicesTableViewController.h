//
//  DevicesTableViewController.h
//  MyStore
//
//  Created by Tu Nguyen on 5/23/16.
//  Copyright © 2016 Tu Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DevicesTableViewController : UITableViewController <UISearchDisplayDelegate, UISearchBarDelegate>

@end
